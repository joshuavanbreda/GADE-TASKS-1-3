using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RealTimeStrategyPOE
{
    public partial class Form1 : Form
    {
        Map m = new Map();
        GameEngine ge = new GameEngine();

        public string Map
        {
            get { return lblMap.Text; }
            set { lblMap.Text = value; }
        }

        public Form1()
        {
            InitializeComponent();
        }

        public string Timer
        {
            get { return timer1.ToString(); }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lblTimer.Text = System.DateTime.Now.ToLongDateString();

            ge.start();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {

        }

        private void btnPause_Click(object sender, EventArgs e)
        {
            ge.pause();
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            ge.start();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
            DialogResult result;

            result = MessageBox.Show("Would you like to exit?", "Exit", buttons);

            if(result == System.Windows.Forms.DialogResult.Yes)
            {
                this.Close();
            }
        }
    }
}
